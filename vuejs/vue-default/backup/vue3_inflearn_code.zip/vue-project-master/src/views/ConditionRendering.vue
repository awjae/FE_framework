<template></template>
<script>
export default {
  name: '',
  components: [],
  data() {
    return {
      sampleData: ''
    };
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  beforeUpdate() {},
  updated() {},
  beforeUnmount(){},
  unmounted() {},
  methods: {}
}
</script>